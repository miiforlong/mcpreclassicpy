// 
// Decompiled by Procyon v0.6.0
// 

package com.mojang.rubydung.level;

import com.mojang.rubydung.phys.AABB;
import java.io.DataOutputStream;
import java.io.OutputStream;
import java.util.zip.GZIPOutputStream;
import java.io.FileOutputStream;
import java.io.DataInputStream;
import java.io.InputStream;
import java.util.zip.GZIPInputStream;
import java.io.FileInputStream;
import java.io.File;
import java.util.ArrayList;

public class Level
{
    public final int width;
    public final int height;
    public final int depth;
    private byte[] blocks;
    private int[] lightDepths;
    private ArrayList<LevelListener> levelListeners;
    
    public Level(final int w, final int h, final int d) {
        this.levelListeners = new ArrayList<LevelListener>();
        this.width = w;
        this.height = h;
        this.depth = d;
        this.blocks = new byte[w * h * d];
        this.lightDepths = new int[w * h];
        for (int x = 0; x < w; ++x) {
            for (int y = 0; y < d; ++y) {
                for (int z = 0; z < h; ++z) {
                    final int i = (y * this.height + z) * this.width + x;
                    this.blocks[i] = (byte)((y <= d * 2 / 3) ? 1 : 0);
                }
            }
        }
        this.calcLightDepths(0, 0, w, h);
        this.load();
    }
    
    public void load() {
        try {
            final DataInputStream dis = new DataInputStream(new GZIPInputStream(new FileInputStream(new File("level.dat"))));
            dis.readFully(this.blocks);
            this.calcLightDepths(0, 0, this.width, this.height);
            for (int i = 0; i < this.levelListeners.size(); ++i) {
                this.levelListeners.get(i).allChanged();
            }
            dis.close();
        }
        catch (final Exception e) {
            e.printStackTrace();
        }
    }
    
    public void save() {
        try {
            final DataOutputStream dos = new DataOutputStream(new GZIPOutputStream(new FileOutputStream(new File("level.dat"))));
            dos.write(this.blocks);
            dos.close();
        }
        catch (final Exception e) {
            e.printStackTrace();
        }
    }
    
    public void calcLightDepths(final int x0, final int y0, final int x1, final int y1) {
        for (int x2 = x0; x2 < x0 + x1; ++x2) {
            for (int z = y0; z < y0 + y1; ++z) {
                final int oldDepth = this.lightDepths[x2 + z * this.width];
                int y2;
                for (y2 = this.depth - 1; y2 > 0 && !this.isLightBlocker(x2, y2, z); --y2) {}
                if (oldDepth != (this.lightDepths[x2 + z * this.width] = y2)) {
                    final int yl0 = (oldDepth < y2) ? oldDepth : y2;
                    final int yl2 = (oldDepth > y2) ? oldDepth : y2;
                    for (int i = 0; i < this.levelListeners.size(); ++i) {
                        this.levelListeners.get(i).lightColumnChanged(x2, z, yl0, yl2);
                    }
                }
            }
        }
    }
    
    public void addListener(final LevelListener levelListener) {
        this.levelListeners.add(levelListener);
    }
    
    public void removeListener(final LevelListener levelListener) {
        this.levelListeners.remove(levelListener);
    }
    
    public boolean isTile(final int x, final int y, final int z) {
        return x >= 0 && y >= 0 && z >= 0 && x < this.width && y < this.depth && z < this.height && this.blocks[(y * this.height + z) * this.width + x] == 1;
    }
    
    public boolean isSolidTile(final int x, final int y, final int z) {
        return this.isTile(x, y, z);
    }
    
    public boolean isLightBlocker(final int x, final int y, final int z) {
        return this.isSolidTile(x, y, z);
    }
    
    public ArrayList<AABB> getCubes(final AABB aABB) {
        final ArrayList<AABB> aABBs = new ArrayList<AABB>();
        int x0 = (int)aABB.x0;
        int x2 = (int)(aABB.x1 + 1.0f);
        int y0 = (int)aABB.y0;
        int y2 = (int)(aABB.y1 + 1.0f);
        int z0 = (int)aABB.z0;
        int z2 = (int)(aABB.z1 + 1.0f);
        if (x0 < 0) {
            x0 = 0;
        }
        if (y0 < 0) {
            y0 = 0;
        }
        if (z0 < 0) {
            z0 = 0;
        }
        if (x2 > this.width) {
            x2 = this.width;
        }
        if (y2 > this.depth) {
            y2 = this.depth;
        }
        if (z2 > this.height) {
            z2 = this.height;
        }
        for (int x3 = x0; x3 < x2; ++x3) {
            for (int y3 = y0; y3 < y2; ++y3) {
                for (int z3 = z0; z3 < z2; ++z3) {
                    if (this.isSolidTile(x3, y3, z3)) {
                        aABBs.add(new AABB((float)x3, (float)y3, (float)z3, (float)(x3 + 1), (float)(y3 + 1), (float)(z3 + 1)));
                    }
                }
            }
        }
        return aABBs;
    }
    
    public float getBrightness(final int x, final int y, final int z) {
        final float dark = 0.8f;
        final float light = 1.0f;
        if (x < 0 || y < 0 || z < 0 || x >= this.width || y >= this.depth || z >= this.height) {
            return light;
        }
        if (y < this.lightDepths[x + z * this.width]) {
            return dark;
        }
        return light;
    }
    
    public void setTile(final int x, final int y, final int z, final int type) {
        if (x < 0 || y < 0 || z < 0 || x >= this.width || y >= this.depth || z >= this.height) {
            return;
        }
        this.blocks[(y * this.height + z) * this.width + x] = (byte)type;
        this.calcLightDepths(x, z, 1, 1);
        for (int i = 0; i < this.levelListeners.size(); ++i) {
            this.levelListeners.get(i).tileChanged(x, y, z);
        }
    }
}
