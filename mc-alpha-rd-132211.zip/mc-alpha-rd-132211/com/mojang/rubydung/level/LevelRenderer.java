// 
// Decompiled by Procyon v0.6.0
// 

package com.mojang.rubydung.level;

import com.mojang.rubydung.HitResult;
import com.mojang.rubydung.phys.AABB;
import org.lwjgl.opengl.GL11;
import com.mojang.rubydung.Player;

public class LevelRenderer implements LevelListener
{
    private static final int CHUNK_SIZE = 16;
    private Level level;
    private Chunk[] chunks;
    private int xChunks;
    private int yChunks;
    private int zChunks;
    Tesselator t;
    
    public LevelRenderer(final Level level) {
        this.t = new Tesselator();
        (this.level = level).addListener(this);
        this.xChunks = level.width / 16;
        this.yChunks = level.depth / 16;
        this.zChunks = level.height / 16;
        this.chunks = new Chunk[this.xChunks * this.yChunks * this.zChunks];
        for (int x = 0; x < this.xChunks; ++x) {
            for (int y = 0; y < this.yChunks; ++y) {
                for (int z = 0; z < this.zChunks; ++z) {
                    final int x2 = x * 16;
                    final int y2 = y * 16;
                    final int z2 = z * 16;
                    int x3 = (x + 1) * 16;
                    int y3 = (y + 1) * 16;
                    int z3 = (z + 1) * 16;
                    if (x3 > level.width) {
                        x3 = level.width;
                    }
                    if (y3 > level.depth) {
                        y3 = level.depth;
                    }
                    if (z3 > level.height) {
                        z3 = level.height;
                    }
                    this.chunks[(x + y * this.xChunks) * this.zChunks + z] = new Chunk(level, x2, y2, z2, x3, y3, z3);
                }
            }
        }
    }
    
    public void render(final Player player, final int layer) {
        Chunk.rebuiltThisFrame = 0;
        final Frustum frustum = Frustum.getFrustum();
        for (int i = 0; i < this.chunks.length; ++i) {
            if (frustum.cubeInFrustum(this.chunks[i].aabb)) {
                this.chunks[i].render(layer);
            }
        }
    }
    
    public void pick(final Player player) {
        final float r = 3.0f;
        final AABB box = player.bb.grow(r, r, r);
        final int x0 = (int)box.x0;
        final int x2 = (int)(box.x1 + 1.0f);
        final int y0 = (int)box.y0;
        final int y2 = (int)(box.y1 + 1.0f);
        final int z0 = (int)box.z0;
        final int z2 = (int)(box.z1 + 1.0f);
        GL11.glInitNames();
        for (int x3 = x0; x3 < x2; ++x3) {
            GL11.glPushName(x3);
            for (int y3 = y0; y3 < y2; ++y3) {
                GL11.glPushName(y3);
                for (int z3 = z0; z3 < z2; ++z3) {
                    GL11.glPushName(z3);
                    if (this.level.isSolidTile(x3, y3, z3)) {
                        GL11.glPushName(0);
                        for (int i = 0; i < 6; ++i) {
                            GL11.glPushName(i);
                            this.t.init();
                            Tile.rock.renderFace(this.t, x3, y3, z3, i);
                            this.t.flush();
                            GL11.glPopName();
                        }
                        GL11.glPopName();
                    }
                    GL11.glPopName();
                }
                GL11.glPopName();
            }
            GL11.glPopName();
        }
    }
    
    public void renderHit(final HitResult h) {
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 1);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, (float)Math.sin(System.currentTimeMillis() / 100.0) * 0.2f + 0.4f);
        this.t.init();
        Tile.rock.renderFace(this.t, h.x, h.y, h.z, h.f);
        this.t.flush();
        GL11.glDisable(3042);
    }
    
    public void setDirty(int x0, int y0, int z0, int x1, int y1, int z1) {
        x0 /= 16;
        x1 /= 16;
        y0 /= 16;
        y1 /= 16;
        z0 /= 16;
        z1 /= 16;
        if (x0 < 0) {
            x0 = 0;
        }
        if (y0 < 0) {
            y0 = 0;
        }
        if (z0 < 0) {
            z0 = 0;
        }
        if (x1 >= this.xChunks) {
            x1 = this.xChunks - 1;
        }
        if (y1 >= this.yChunks) {
            y1 = this.yChunks - 1;
        }
        if (z1 >= this.zChunks) {
            z1 = this.zChunks - 1;
        }
        for (int x2 = x0; x2 <= x1; ++x2) {
            for (int y2 = y0; y2 <= y1; ++y2) {
                for (int z2 = z0; z2 <= z1; ++z2) {
                    this.chunks[(x2 + y2 * this.xChunks) * this.zChunks + z2].setDirty();
                }
            }
        }
    }
    
    @Override
    public void tileChanged(final int x, final int y, final int z) {
        this.setDirty(x - 1, y - 1, z - 1, x + 1, y + 1, z + 1);
    }
    
    @Override
    public void lightColumnChanged(final int x, final int z, final int y0, final int y1) {
        this.setDirty(x - 1, y0 - 1, z - 1, x + 1, y1 + 1, z + 1);
    }
    
    @Override
    public void allChanged() {
        this.setDirty(0, 0, 0, this.level.width, this.level.depth, this.level.height);
    }
}
