// 
// Decompiled by Procyon v0.6.0
// 

package com.mojang.rubydung;

public class HitResult
{
    public int x;
    public int y;
    public int z;
    public int o;
    public int f;
    
    public HitResult(final int x, final int y, final int z, final int o, final int f) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.o = o;
        this.f = f;
    }
}
